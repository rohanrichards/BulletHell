﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Experimental.Rendering.Universal;

//when something get into the alta, make the runes glow
namespace Cainos.PixelArtTopDown_Basic
{

    public class PropsAltar : MonoBehaviour
    {
        public List<SpriteRenderer> runes;
        public Light2D[] lights;
        public float lerpSpeed;

        private Color curColor;
        private Color targetColor;
        private Color currentLightColor;
        private Color targetLightColor;

        private Color baseColor = new Color(0.005f, 0.536f, 1);

        private void OnTriggerEnter2D(Collider2D other)
        {
            targetColor = new Color(1, 1, 1, 1);
            targetLightColor = baseColor;
        }

        private void OnTriggerExit2D(Collider2D other)
        {
            targetColor = new Color(1, 1, 1, 0);
            targetLightColor = new Color(0, 0, 0);
        }

        private void Update()
        {
            curColor = Color.Lerp(curColor, targetColor, lerpSpeed * Time.deltaTime);
            currentLightColor = Color.Lerp(currentLightColor, targetLightColor, lerpSpeed * Time.deltaTime);

            foreach (var r in runes)
            {
                r.color = curColor;
            }

            foreach (var l in lights)
            {
                l.color = currentLightColor;
            }
        }
    }
}
